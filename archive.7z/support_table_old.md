## CurseForge

|																																																	    |  1.17.1   |  1.18.X  |  1.19.2   |  1.20.1    |  1.21.1    |		Datapack Version			|
|---------------------------------------------------------------------------------------------------------------------------------------------|:-----------:|:----------:|:-----------:|:-----------:|:-----------:|:--------------------------------------:|
| [Ad Astra](https://www.curseforge.com/minecraft/mc-mods/ad-astra)   																|				  |			   |✔			|✔			  |			   |												|
| [Ad Astra: Proxima Plus](https://www.curseforge.com/minecraft/mc-mods/ad-astra-proxima-plus)				|				  |			   |      		    |✔			  |			   |												|
| [Alex's Caves](https://www.curseforge.com/minecraft/mc-mods/alexs-caves)														|				  |			   |      		    |✔			  |			   |												|
| [Alex's Mobs](https://www.curseforge.com/minecraft/mc-mods/alexs-mobs)														|✔		 	  |✔		   |✔			|✔			  |			   |1.4											|
| [Aquamirae](https://www.curseforge.com/minecraft/mc-mods/ob-aquamirae)													|				  |✔		   |✔			|✔			  |			   |2.0											|
| [Aquatic Frontiers](https://www.curseforge.com/minecraft/mc-mods/aquatic-frontiers)									|				  |			   |✔			|✔			  |			   |												|
| [Atmospheric](https://www.curseforge.com/minecraft/mc-mods/atmospheric)													|				  |			   |      		    |✔		      |			   |3.1							  				|
| [Autumnity](https://www.curseforge.com/minecraft/mc-mods/autumnity)															|				  |✔		   |✔		    |✔			  |			   |2.1											|
| [Biome Makeover](https://www.curseforge.com/minecraft/mc-mods/biome-makeover-forge)					 	|				  |✔		   |✔		    |✔			  |			   |2.0											|
| [Bygone Nether](https://www.curseforge.com/minecraft/mc-mods/bygone-nether)											|				  |✔		   |✔		    |✔			  |			   |2.0											|
| [Caverns & Chasms](https://www.curseforge.com/minecraft/mc-mods/caverns-and-chasms)						|				  |			   |      		    |✔		      |			   |3.1							  				|
| [Cloud Storage](https://www.curseforge.com/minecraft/mc-mods/alexs-cloud-storage)									|				  |			   |      		    |✔		      |			   |3.1							  				|
| [Deep Dark: Regrowth](https://www.curseforge.com/minecraft/mc-mods/deep-dark-regrowth)					|				  |			   |✔		    |✔			  |			   |2.0											|
| [Draconic Evolution](https://www.curseforge.com/minecraft/mc-mods/draconic-evolution)							|				  |			   |      		    |✔		      |			   |3.1							  				|
| [Ecologics](https://www.curseforge.com/minecraft/mc-mods/ecologics)																|				  |✔		   |✔			|✔			  |			   |												|
| [The Endergetic Expansion](https://www.curseforge.com/minecraft/mc-mods/endergetic)								|				  |			   |✔			|✔			  |			   |2.0											|
| [Enlightend](https://www.curseforge.com/minecraft/mc-mods/enlightend)														|				  |✔		   |✔			|				  |			   |3.0											|
| [Ender Zoology](https://www.curseforge.com/minecraft/mc-mods/ender-zoology)											|				  |			   |✔			|✔			  |✔		   |												|
| [Environmental](https://www.curseforge.com/minecraft/mc-mods/environmental)											|				  |			   |      		    |✔		      |			   |3.1							  				|
| [Eternal Starlight](https://www.curseforge.com/minecraft/mc-mods/eternal-starlight)									|				  |			   |			    |				  |✔		   |1.6											|
| [Friends & Foes](https://www.curseforge.com/minecraft/mc-mods/friends-and-foes-forge)							|				  |✔		   |✔			|✔			  |✔		   |1.4											|
| [Galosphere](https://www.curseforge.com/minecraft/mc-mods/galosphere)														|				  |			   |      		    |✔			  |			   |												|
| [Ice & Fire](https://www.curseforge.com/minecraft/mc-mods/ice-and-fire-dragons)     				   					|✔  		  |✔		   |✔			|✔			  |			   |1.5											|
| [Iron's Spells 'n Spellbooks](https://www.curseforge.com/minecraft/mc-mods/irons-spells-n-spellbooks)	|				  |✔		   |✔			|✔			  |✔		   |1.4											|
| [Jaden's Nether Expansion](https://www.curseforge.com/minecraft/mc-mods/jadens-nether-expansion)	|				  |      		   |      		    |✔			  |			   |2.1											|
| [L_Ender's Cataclysm](https://www.curseforge.com/minecraft/mc-mods/lendercataclysm)							|				  |✔		   |✔			|✔			  |✔		   |3.0											|
| [Mob Compack](https://www.curseforge.com/minecraft/mc-mods/mob-compack)											|				  |			   |      		    |✔		      |			   |3.1							  				|
| [More Useful Copper](https://www.curseforge.com/minecraft/mc-mods/more-useful-copper-2-0)				|				  |			   |      		    |✔		      |			   |3.1							  				|
| [Neapolitan](https://www.curseforge.com/minecraft/mc-mods/neapolitan)														|				  |			   |      		    |✔		      |			   |3.1							  				|
| [The Outer End](https://www.curseforge.com/minecraft/mc-mods/the-outer-end)											|				  |			   |      		    |✔			  |			   |												|
| [Quark](https://www.curseforge.com/minecraft/mc-mods/quark)                   														|				  |✔		   |✔			|✔			  |			   |												|
| [Savage & Ravage](https://www.curseforge.com/minecraft/mc-mods/savage-and-ravage)								|				  |			   |      		    |✔		      |			   |3.1							  				|
| [Terramity](https://www.curseforge.com/minecraft/mc-mods/terramity)																|				  |			   |      		    |✔		      |			   |3.1							  				|
| [Tinkers' Construct](https://www.curseforge.com/minecraft/mc-mods/tinkers-construct)								|				  |✔		   |✔   	    |✔		      |			   |2.1.1 (3.0 for 1.20 support)	|
| [Upgrade Aquatic](https://www.curseforge.com/minecraft/mc-mods/upgrade-aquatic)									|				  |✔		   |✔			|✔			  |			   |1.1											|
| [YUNG's Cave Biomes](https://www.curseforge.com/minecraft/mc-mods/yungs-cave-biomes)          			|				  |✔		   |      		    |✔			  |			   |1.5											|

<br />

## Modrinth

|																																															|  1.17.1   |  1.18.X  |  1.19.2   |  1.20.1    |  1.21.1    |		Datapack Version			|
|-------------------------------------------------------------------------------------------------------------------------------------|:-----------:|:----------:|:-----------:|:-----------:|:-----------:|:--------------------------------------:|
| [Ad Astra](https://modrinth.com/mod/ad-astra)   																							|				  |			   |✔			|✔			  |			   |												|
| [Ad Astra: Proxima Plus](https://www.curseforge.com/minecraft/mc-mods/ad-astra-proxima-plus)	|				  |			   |      		    |✔			  |			   |												|
| [Alex's Caves](https://modrinth.com/mod/alexs-caves)																					|				  |			   |      		    |✔			  |			   |												|
| [Alex's Mobs](https://modrinth.com/mod/alexs-mobs)																					|✔		 	  |✔		   |✔			|✔			  |			   |1.4											|
| [Aquamirae](https://modrinth.com/mod/aquamirae)																						|				  |✔		   |✔			|✔			  |			   |2.0											|
| [Aquatic Frontiers](https://modrinth.com/mod/aquatic-frontiers)																|				  |			   |✔			|✔			  |			   |												|
| [Atmospheric](https://modrinth.com/mod/atmospheric)																				|				  |			   |      		    |✔		      |			   |3.1							  				|
| [Autumnity](https://modrinth.com/mod/autumnity)																						|				  |✔		   |✔		    |✔			  |			   |2.1											|
| [Biome Makeover](https://modrinth.com/mod/biome-makeover)					 											|				  |✔		   |✔		    |✔			  |			   |2.0											|
| [Bygone Nether](https://modrinth.com/mod/bygone-nether)																		|				  |✔		   |✔		    |✔			  |			   |2.0											|
| [Caverns & Chasms](https://modrinth.com/mod/caverns-and-chasms)														|				  |			   |      		    |✔		      |			   |3.1							  				|
| [Cloud Storage](https://modrinth.com/mod/alexs-cloud-storage)																|				  |			   |      		    |✔		      |			   |3.1							  				|
| [Deep Dark: Regrowth](https://www.curseforge.com/minecraft/mc-mods/deep-dark-regrowth)		|				  |			   |✔		    |✔			  |			   |2.0											|
| [Draconic Evolution](https://modrinth.com/mod/draconic-evolution)														|				  |			   |      		    |✔		      |			   |3.1							  				|
| [Ecologics](https://modrinth.com/mod/ecologics)																							|				  |✔		   |✔			|✔			  |			   |												|
| [The Endergetic Expansion](https://modrinth.com/mod/endergetic)															|				  |			   |✔			|✔			  |			   |2.0											|
| [Enlightend](https://modrinth.com/mod/enlightend)																						|				  |✔		   |✔			|				  |			   |3.0											|
| [Ender Zoology](https://modrinth.com/mod/ender-zoology)																			|				  |			   |✔			|✔			  |✔		   |												|
| [Environmental](https://modrinth.com/mod/environmental)																		|				  |			   |      		    |✔		      |			   |3.1							  				|
| [Eternal Starlight](https://modrinth.com/mod/eternal-starlight)																	|				  |			   |			    |				  |✔		   |1.6											|
| [Friends & Foes](https://modrinth.com/mod/friends-and-foes-forge)															|				  |✔		   |✔			|✔			  |✔		   |1.4											|
| [Galosphere](https://modrinth.com/mod/galosphere)																					|				  |			   |      		    |✔			  |			   |												|
| [Ice & Fire](https://modrinth.com/mod/ice-and-fire-dragons)     				   													|✔  		  |✔		   |✔			|✔			  |			   |1.5											|
| [Iron's Spells 'n Spellbooks](https://modrinth.com/mod/irons-spells-n-spellbooks)									|				  |✔		   |✔			|✔			  |✔		   |1.4											|
| [Jaden's Nether Expansion](https://modrinth.com/mod/jadens-nether-expansion)								|				  |      		   |      		    |✔			  |			   |2.1											|
| [L_Ender's Cataclysm](https://modrinth.com/mod/l_enders-cataclysm)													|				  |✔		   |✔			|✔			  |✔		   |3.0											|
| [Mob Compack](https://www.curseforge.com/minecraft/mc-mods/mob-compack)								|				  |			   |      		    |✔		      |			   |3.1							  				|
| [More Useful Copper](https://modrinth.com/mod/more-useful-copper)													|				  |			   |      		    |✔		      |			   |3.1							  				|
| [Neapolitan](https://modrinth.com/mod/neapolitan)																						|				  |			   |      		    |✔		      |			   |3.1							  				|
| [The Outer End](https://modrinth.com/mod/the-outer-end)																			|				  |			   |      		    |✔			  |			   |												|
| [Quark](https://modrinth.com/mod/quark)                   																						|				  |✔		   |✔			|✔			  |			   |												|
| [Savage & Ravage](https://modrinth.com/mod/savage-and-ravage)															|				  |			   |      		    |✔		      |			   |3.1							  				|
| [Terramity](https://modrinth.com/mod/terramity)																							|				  |			   |      		    |✔		      |			   |3.1							  				|
| [Tinkers' Construct](https://modrinth.com/mod/tinkers-construct)																|				  |✔		   |✔   	    |✔		      |			   |2.1.1 (3.0 for 1.20 support)	|
| [Upgrade Aquatic](https://modrinth.com/mod/upgrade-aquatic)																|				  |✔		   |✔			|✔			  |			   |1.1											|
| [YUNG's Cave Biomes](https://modrinth.com/mod/yungs-cave-biomes)          											|				  |✔		   |      		    |✔			  |			   |1.5											|

<br />

Empty new line for when I add mod support:
| [Name](Link)	|				  |			   |      		    |			      |			   |								  |